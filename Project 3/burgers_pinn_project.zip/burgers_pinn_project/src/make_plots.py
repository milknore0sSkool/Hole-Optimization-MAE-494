from __future__ import annotations

import math
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"
FIGURES = ROOT / "figures"
FIGURES.mkdir(exist_ok=True)


def main():
    metrics = pd.read_csv(RESULTS / "metrics.csv")
    hist = pd.read_csv(RESULTS / "loss_history.csv")

    # P3: error vs. difficulty knob.
    fig, ax = plt.subplots(figsize=(7, 4.5))
    for method in ["finite_volume_257", "PINN_Adam", "PINN_Adam_LBFGS"]:
        sub = metrics[metrics.method == method].sort_values("nu")
        ax.plot(sub.nu, sub.relative_l2, marker="o", label=method.replace("_", " "))
    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlabel("Viscosity nu (lower = harder / sharper shock)")
    ax.set_ylabel("Relative L2 error")
    ax.set_title("P3 — Error vs. viscosity difficulty knob")
    ax.legend()
    ax.grid(True, which="both", alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIGURES / "p3_error_vs_viscosity.png", dpi=180)
    plt.close(fig)

    # P2: individual loss components for hard case, improved model.
    hard_tag = "0.01_over_pi"
    sub = hist[(hist.nu_tag == hard_tag) & (hist.method == "PINN_Adam_LBFGS")].sort_values("step")
    fig, ax = plt.subplots(figsize=(7, 4.5))
    for key, label in [("pde", "PDE residual"), ("ic", "Initial condition"), ("bc", "Boundary")]:
        ax.plot(sub.step, sub[key], label=label)
    ax.set_yscale("log")
    ax.set_xlabel("Optimization step / function evaluation")
    ax.set_ylabel("MSE loss component")
    ax.set_title("P2 — Loss components, hard case")
    ax.legend()
    ax.grid(True, which="both", alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIGURES / "p2_loss_components_hard.png", dpi=180)
    plt.close(fig)

    # P4: hard-case pointwise error field for baseline.
    ref = np.load(RESULTS / f"reference_eval_{hard_tag}.npz")
    pred_base = np.load(RESULTS / f"prediction_PINN_Adam_{hard_tag}.npz")["u"]
    pred_fix = np.load(RESULTS / f"prediction_PINN_Adam_LBFGS_{hard_tag}.npz")["u"]
    x, t, u_ref = ref["x"], ref["t"], ref["u"]

    for pred, name, title in [
        (pred_base, "p4_error_field_adam.png", "P4 — Pointwise error: Adam-only"),
        (pred_fix, "p4_error_field_adam_lbfgs.png", "P4 — Pointwise error: Adam + L-BFGS"),
    ]:
        err = np.abs(pred - u_ref)
        fig, ax = plt.subplots(figsize=(7, 4.5))
        im = ax.imshow(err, origin="lower", aspect="auto", extent=[x.min(), x.max(), t.min(), t.max()])
        ax.set_xlabel("x")
        ax.set_ylabel("t")
        ax.set_title(title)
        fig.colorbar(im, ax=ax, label="absolute error")
        fig.tight_layout()
        fig.savefig(FIGURES / name, dpi=180)
        plt.close(fig)

    # P4: Fourier spectrum of final-time error.
    fig, ax = plt.subplots(figsize=(7, 4.5))
    for pred, label in [(pred_base, "Adam-only"), (pred_fix, "Adam + L-BFGS")]:
        e = pred[-1] - u_ref[-1]
        spec = np.abs(np.fft.rfft(e))
        k = np.fft.rfftfreq(len(e), d=(x[1] - x[0]))
        ax.semilogy(k[1:], spec[1:] + 1e-14, label=label)
    ax.set_xlabel("Spatial frequency")
    ax.set_ylabel("|FFT(error)|")
    ax.set_title("P4 — Final-time error spectrum, hard case")
    ax.legend()
    ax.grid(True, which="both", alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIGURES / "p4_error_spectrum_hard.png", dpi=180)
    plt.close(fig)

    # P5: training cost.
    sub = metrics[metrics.method.isin(["PINN_Adam", "PINN_Adam_LBFGS"])].copy()
    sub["label"] = sub.nu.map(lambda v: f"nu={v:.4g}") + "\n" + sub.method.str.replace("PINN_", "", regex=False).str.replace("_", "+", regex=False)
    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.bar(sub.label, sub.train_seconds)
    ax.set_ylabel("Training wall time (s)")
    ax.set_title("P5 — Training cost on CPU")
    ax.tick_params(axis="x", rotation=25)
    fig.tight_layout()
    fig.savefig(FIGURES / "p5_training_cost.png", dpi=180)
    plt.close(fig)

    # Snapshot comparison at hard case final time.
    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.plot(x, u_ref[-1], label="Finite-volume reference")
    ax.plot(x, pred_base[-1], linestyle="--", label="PINN Adam")
    ax.plot(x, pred_fix[-1], linestyle=":", label="PINN Adam + L-BFGS")
    ax.set_xlabel("x")
    ax.set_ylabel("u(x, t=1)")
    ax.set_title("Hard case final-time solution")
    ax.legend()
    ax.grid(True, alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIGURES / "hard_case_final_time.png", dpi=180)
    plt.close(fig)


if __name__ == "__main__":
    main()
