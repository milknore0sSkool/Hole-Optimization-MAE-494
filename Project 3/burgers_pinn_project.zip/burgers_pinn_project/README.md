# Project 3 — Optimizing a PINN for the 1-D Viscous Burgers Equation

This repository is a complete computational case study for a **Path C (diagnosis + fix)** project.

## One-sentence result

As viscosity decreases and the Burgers solution develops a sharp internal layer, an Adam-only PINN degrades badly; keeping the network, points, and loss weights fixed but adding an L-BFGS second stage substantially reduces error, showing that optimization is a major part of the failure.

## Problem

We solve

\[
u_t + u u_x - \nu u_{xx}=0,
\qquad x\in[-1,1],\quad t\in[0,1],
\]

with

\[
u(x,0)=-\sin(\pi x),\qquad u(-1,t)=u(1,t)=0.
\]

The difficulty knob is viscosity:

- `nu = 0.05` — easy/smooth
- `nu = 0.01` — intermediate
- `nu = 0.01/pi ~= 0.0031831` — hard/sharp shock

The hard case is the standard Burgers example used in the original PINN work.

## Public data

The public reference file is only about **203 KB**:

`burgers_shock.mat`

Download it automatically:

```bash
python src/download_data.py
```

Canonical source:

`https://raw.githubusercontent.com/maziarraissi/PINNs/master/appendix/Data/burgers_shock.mat`

The file contains `x`, `t`, and `usol`, and loads directly in both MATLAB and Python.

Python:

```python
from scipy.io import loadmat
D = loadmat('data/burgers_shock.mat')
x = D['x'].squeeze()
t = D['t'].squeeze()
u = D['usol']
```

MATLAB:

```matlab
D = load('data/burgers_shock.mat');
x = D.x(:);
t = D.t(:);
u = real(D.usol);
```

A ready-to-run MATLAB loader is included as `load_burgers_data.m`.

## Run the full Python project

```bash
python -m pip install -r requirements.txt
python src/download_data.py        # recommended; not required for the internal solver study
python run_all.py
```

Outputs are written to:

- `results/metrics.csv`
- `results/loss_history.csv`
- `figures/`
- `models/`
- generated `.npz` and `.mat` reference files in `data/`

## Current reproduced results

| Viscosity | Finite-volume baseline | PINN Adam | PINN Adam + L-BFGS |
|---:|---:|---:|---:|
| 0.05 | 0.0057 | 0.1391 | **0.0133** |
| 0.01 | 0.0131 | 0.3835 | **0.1576** |
| 0.01/pi | 0.0231 | 0.4254 | **0.2859** |

Values are relative L2 error against an independently generated higher-resolution finite-volume reference.

For the hard case, a supervised fit using the **same neural-network architecture** reaches `0.0557` relative L2 error. This is the controlled diagnostic showing that the network can represent the solution much better than the Adam-only physics-informed training finds.

## Project files

- `PROJECT_REPORT.md` — report organized around P1–P5 and Path C
- `RECOMMENDATION_MEMO.md` — one-page researcher-facing memo draft
- `OUTREACH_AND_INTERVIEW.md` — the only part that cannot be truthfully completed without your actual researcher/interview
- `burgers_pinn_project.ipynb` — notebook version / presentation path
- `src/numerics.py` — conventional finite-volume solver
- `src/pinn.py` — PINN and optimization routines
- `src/run_experiments.py` — experimental driver
- `src/make_plots.py` — required plots
- `src/download_data.py` — tiny public dataset downloader
- `load_burgers_data.m` — MATLAB loader

## What still requires a real researcher

The course brief requires a real researcher interview and a memo sent to that researcher. This repository does **not** invent an interview. Fill in `OUTREACH_AND_INTERVIEW.md` with the person you actually contact, then adapt `RECOMMENDATION_MEMO.md` to their application.

## Reproducibility

The current run used:

- random seed: 0
- PyTorch 2.10 CPU
- 4 PyTorch threads
- 500 Adam epochs
- 700 collocation points
- 120 L-BFGS iterations for the optimized run
- network: 3 hidden layers, width 48, tanh activation

Exact settings are saved in `results/environment.json`.
