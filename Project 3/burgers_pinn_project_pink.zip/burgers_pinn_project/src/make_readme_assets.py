from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "assets"
ASSETS.mkdir(exist_ok=True)

FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
BOLD = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
MONO = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"


def font(path, size):
    return ImageFont.truetype(path, size=size)


def rounded_rect(draw, xy, radius, fill, outline=None, width=1):
    draw.rounded_rectangle(xy, radius=radius, fill=fill, outline=outline, width=width)


def banner():
    W, H = 1600, 520
    im = Image.new("RGB", (W, H))
    px = im.load()
    c0 = np.array([47, 18, 43], dtype=float)
    c1 = np.array([116, 28, 88], dtype=float)
    c2 = np.array([255, 79, 163], dtype=float)
    for y in range(H):
        for x in range(W):
            t = x / (W - 1)
            v = y / (H - 1)
            if t < 0.7:
                a = t / 0.7
                c = (1-a)*c0 + a*c1
            else:
                a = (t-0.7)/0.3
                c = (1-a)*c1 + a*c2
            # slight vertical darkening
            c = c * (0.98 - 0.12*v)
            px[x, y] = tuple(np.clip(c, 0, 255).astype(int))

    d = ImageDraw.Draw(im, "RGBA")
    # Decorative soft circles
    for cx, cy, r, alpha in [(1320,80,180,28),(1480,300,240,25),(1180,390,145,20)]:
        d.ellipse((cx-r, cy-r, cx+r, cy+r), fill=(255,255,255,alpha))

    # Tag
    rounded_rect(d, (86, 58, 532, 108), 22, fill=(255,255,255,34), outline=(255,255,255,70), width=2)
    d.text((111, 70), "PATH C  •  BURGERS EQUATION  •  PYTORCH", font=font(BOLD, 22), fill=(255,238,248,255))

    d.text((84, 143), "PROJECT 3", font=font(BOLD, 34), fill=(255,180,219,255))
    d.text((82, 190), "PINN OPTIMIZATION", font=font(BOLD, 68), fill=(255,255,255,255))
    d.text((86, 278), "Diagnose the failure. Fix the optimizer. Measure the physics.", font=font(FONT, 27), fill=(249,223,239,255))

    rounded_rect(d, (86, 348, 712, 428), 20, fill=(35,12,31,105), outline=(255,255,255,45), width=2)
    d.text((116, 367), "u_t + u u_x - ν u_xx = 0", font=font(MONO, 31), fill=(255,255,255,255))

    # Stylized Burgers profiles on the right
    x0, y0, ww, hh = 910, 135, 570, 260
    d.line((x0, y0+hh/2, x0+ww, y0+hh/2), fill=(255,255,255,80), width=2)
    d.line((x0+ww/2, y0, x0+ww/2, y0+hh), fill=(255,255,255,50), width=2)
    xs = np.linspace(-1, 1, 240)
    curves = [
        (np.tanh(-2.2*xs), (255,210,233,145), 3),
        (np.tanh(-5.0*xs), (255,151,204,190), 4),
        (np.tanh(-12.0*xs), (255,255,255,235), 5),
    ]
    for vals, color, width in curves:
        pts=[]
        for xx, yy in zip(xs, vals):
            pxv = x0 + (xx+1)/2 * ww
            pyv = y0 + (1-(yy+1)/2) * hh
            pts.append((pxv, pyv))
        d.line(pts, fill=color, width=width)
    d.text((1035, 414), "lower ν  →  sharper internal layer", font=font(FONT, 21), fill=(255,229,244,230))

    im.save(ASSETS / "hero_banner.png", quality=95)


def result_cards():
    W, H = 1600, 440
    im = Image.new("RGB", (W, H), "#fff7fb")
    d = ImageDraw.Draw(im)
    d.text((70, 38), "THE RESULT, AT A GLANCE", font=font(BOLD, 28), fill="#5b214d")
    d.text((70, 80), "One controlled change — Adam → L-BFGS — improves every viscosity case.", font=font(FONT, 24), fill="#7c6273")

    cards = [
        (70, 145, 500, 365, "90.5%", "error reduction", "ν = 0.05", "#ff4fa3"),
        (585, 145, 1015, 365, "42.5 → 28.6%", "hard-case error", "Adam → L-BFGS", "#d81b7d"),
        (1100, 145, 1530, 365, "5.57%", "supervised fit error", "capacity check", "#8b5cf6"),
    ]
    for x1,y1,x2,y2,big,label,small,accent in cards:
        rounded_rect(d, (x1,y1,x2,y2), 24, fill="#ffffff", outline="#ead6e1", width=2)
        d.rounded_rectangle((x1, y1, x1+12, y2), radius=6, fill=accent)
        d.text((x1+38, y1+33), big, font=font(BOLD, 44), fill="#321b2a")
        d.text((x1+38, y1+100), label, font=font(BOLD, 22), fill=accent)
        d.text((x1+38, y1+145), small, font=font(FONT, 19), fill="#7c6273")
    im.save(ASSETS / "results_summary.png", quality=95)


if __name__ == "__main__":
    banner()
    result_cards()
