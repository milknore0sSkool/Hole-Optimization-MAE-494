from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"
FIGURES = ROOT / "figures"
FIGURES.mkdir(exist_ok=True)

# GitHub-friendly pink theme. Keep the science readable first, decorative second.
BG = "#fff7fb"
PANEL = "#fffafd"
TEXT = "#321b2a"
MUTED = "#7c6273"
GRID = "#ead6e1"
PINK = "#ff4fa3"
MAGENTA = "#d81b7d"
PURPLE = "#8b5cf6"
PLUM = "#5b214d"
FV = "#54485f"

plt.rcParams.update(
    {
        "figure.facecolor": BG,
        "axes.facecolor": PANEL,
        "axes.edgecolor": "#d9b9ca",
        "axes.labelcolor": TEXT,
        "axes.titlecolor": TEXT,
        "text.color": TEXT,
        "xtick.color": MUTED,
        "ytick.color": MUTED,
        "font.size": 11,
        "axes.titlesize": 15,
        "axes.titleweight": "bold",
        "axes.labelsize": 11.5,
        "legend.frameon": True,
        "legend.facecolor": "#ffffff",
        "legend.edgecolor": "#e4c6d7",
        "savefig.facecolor": BG,
        "savefig.bbox": "tight",
    }
)


def style_ax(ax):
    ax.grid(True, which="both", color=GRID, linewidth=0.8, alpha=0.75)
    ax.set_axisbelow(True)
    for spine in ax.spines.values():
        spine.set_color("#d7b4c7")
    return ax


def main():
    metrics = pd.read_csv(RESULTS / "metrics.csv")
    hist = pd.read_csv(RESULTS / "loss_history.csv")

    # P3: error vs. difficulty knob.
    fig, ax = plt.subplots(figsize=(8.2, 5.1))
    methods = [
        ("finite_volume_257", "Finite volume", FV, "o", "-"),
        ("PINN_Adam", "PINN · Adam", PINK, "o", "--"),
        ("PINN_Adam_LBFGS", "PINN · Adam → L-BFGS", PURPLE, "o", "-"),
    ]
    for method, label, color, marker, ls in methods:
        sub = metrics[metrics.method == method].sort_values("nu")
        ax.plot(
            sub.nu,
            sub.relative_l2,
            marker=marker,
            markersize=8,
            linewidth=2.8,
            linestyle=ls,
            color=color,
            label=label,
        )
    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlabel("Viscosity, ν  (lower → sharper / harder)")
    ax.set_ylabel("Relative $L_2$ error")
    ax.set_title("P3 · Accuracy collapses as viscosity falls")
    ax.text(
        0.015,
        0.03,
        "The optimizer fix helps at every viscosity,\nbut the sharpest case remains difficult.",
        transform=ax.transAxes,
        fontsize=10,
        color=MUTED,
        va="bottom",
    )
    ax.legend(loc="upper right")
    style_ax(ax)
    fig.tight_layout()
    fig.savefig(FIGURES / "p3_error_vs_viscosity.png", dpi=220)
    plt.close(fig)

    # P2: individual loss components for hard case, improved model.
    hard_tag = "0.01_over_pi"
    sub = hist[(hist.nu_tag == hard_tag) & (hist.method == "PINN_Adam_LBFGS")].sort_values("step")
    fig, ax = plt.subplots(figsize=(8.2, 5.1))
    for key, label, color in [
        ("pde", "PDE residual", MAGENTA),
        ("ic", "Initial condition", PURPLE),
        ("bc", "Boundary condition", PINK),
    ]:
        ax.plot(sub.step, sub[key], label=label, color=color, linewidth=2.4)
    ax.set_yscale("log")
    ax.set_xlabel("Optimization step / function evaluation")
    ax.set_ylabel("MSE loss component")
    ax.set_title("P2 · Loss components on the hardest case")
    ax.legend()
    style_ax(ax)
    fig.tight_layout()
    fig.savefig(FIGURES / "p2_loss_components_hard.png", dpi=220)
    plt.close(fig)

    # P4: hard-case pointwise error fields.
    ref = np.load(RESULTS / f"reference_eval_{hard_tag}.npz")
    pred_base = np.load(RESULTS / f"prediction_PINN_Adam_{hard_tag}.npz")["u"]
    pred_fix = np.load(RESULTS / f"prediction_PINN_Adam_LBFGS_{hard_tag}.npz")["u"]
    x, t, u_ref = ref["x"], ref["t"], ref["u"]

    vmax = max(np.abs(pred_base - u_ref).max(), np.abs(pred_fix - u_ref).max())
    for pred, name, title in [
        (pred_base, "p4_error_field_adam.png", "P4 · Pointwise error — Adam only"),
        (pred_fix, "p4_error_field_adam_lbfgs.png", "P4 · Pointwise error — Adam → L-BFGS"),
    ]:
        err = np.abs(pred - u_ref)
        fig, ax = plt.subplots(figsize=(8.2, 5.1))
        im = ax.imshow(
            err,
            origin="lower",
            aspect="auto",
            extent=[x.min(), x.max(), t.min(), t.max()],
            cmap="RdPu",
            vmin=0,
            vmax=vmax,
        )
        ax.set_xlabel("x")
        ax.set_ylabel("t")
        ax.set_title(title)
        cbar = fig.colorbar(im, ax=ax, pad=0.02)
        cbar.set_label("Absolute error", color=TEXT)
        cbar.ax.tick_params(colors=MUTED)
        for spine in ax.spines.values():
            spine.set_color("#d7b4c7")
        fig.tight_layout()
        fig.savefig(FIGURES / name, dpi=220)
        plt.close(fig)

    # P4: Fourier spectrum of final-time error.
    fig, ax = plt.subplots(figsize=(8.2, 5.1))
    for pred, label, color, ls in [
        (pred_base, "Adam only", PINK, "--"),
        (pred_fix, "Adam → L-BFGS", PURPLE, "-"),
    ]:
        e = pred[-1] - u_ref[-1]
        spec = np.abs(np.fft.rfft(e))
        k = np.fft.rfftfreq(len(e), d=(x[1] - x[0]))
        ax.semilogy(k[1:], spec[1:] + 1e-14, label=label, color=color, linewidth=2.4, linestyle=ls)
    ax.set_xlabel("Spatial frequency")
    ax.set_ylabel("|FFT(error)|")
    ax.set_title("P4 · High-frequency error survives the optimizer fix")
    ax.legend()
    style_ax(ax)
    fig.tight_layout()
    fig.savefig(FIGURES / "p4_error_spectrum_hard.png", dpi=220)
    plt.close(fig)

    # P5: training cost.
    sub = metrics[metrics.method.isin(["PINN_Adam", "PINN_Adam_LBFGS"])].copy()
    sub["label"] = sub.nu.map(lambda v: f"ν={v:.4g}") + "\n" + sub.method.str.replace("PINN_", "", regex=False).str.replace("_", " → ", regex=False)
    colors = [PINK if "Adam_LBFGS" not in m else PURPLE for m in sub.method]
    fig, ax = plt.subplots(figsize=(9.2, 5.1))
    bars = ax.bar(sub.label, sub.train_seconds, color=colors, edgecolor="#ffffff", linewidth=1.0)
    ax.bar_label(bars, fmt="%.2f s", padding=3, fontsize=9, color=MUTED)
    ax.set_ylabel("Training wall time (s)")
    ax.set_title("P5 · The L-BFGS refinement adds modest CPU cost")
    ax.tick_params(axis="x", rotation=0)
    ax.set_ylim(0, max(sub.train_seconds) * 1.22)
    style_ax(ax)
    fig.tight_layout()
    fig.savefig(FIGURES / "p5_training_cost.png", dpi=220)
    plt.close(fig)

    # Snapshot comparison at hard-case final time.
    fig, ax = plt.subplots(figsize=(8.2, 5.1))
    ax.plot(x, u_ref[-1], label="Finite-volume reference", color=FV, linewidth=3.0)
    ax.plot(x, pred_base[-1], linestyle="--", label="PINN · Adam", color=PINK, linewidth=2.4)
    ax.plot(x, pred_fix[-1], linestyle="-", label="PINN · Adam → L-BFGS", color=PURPLE, linewidth=2.4)
    ax.set_xlabel("x")
    ax.set_ylabel("u(x, t=1)")
    ax.set_title("Hard case · Final-time solution")
    ax.legend(loc="best")
    style_ax(ax)
    fig.tight_layout()
    fig.savefig(FIGURES / "hard_case_final_time.png", dpi=220)
    plt.close(fig)


if __name__ == "__main__":
    main()
