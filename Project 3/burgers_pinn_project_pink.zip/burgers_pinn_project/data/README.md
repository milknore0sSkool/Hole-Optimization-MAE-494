# Data

## Public dataset used

The project uses the classic viscous Burgers reference solution distributed with the original PINNs examples:

- File: `burgers_shock.mat` (~203 KB)
- Canonical source: `https://raw.githubusercontent.com/maziarraissi/PINNs/master/appendix/Data/burgers_shock.mat`
- Alternate public mirror: `https://github.com/XinyuanLiao/Adaptive-optimization-of-PINN/raw/refs/heads/main/burgers_shock.mat`

Download automatically from the project root:

```bash
python src/download_data.py
```

The MAT file contains `x`, `t`, and `usol`. The canonical problem is

`u_t + u u_x - (0.01/pi) u_xx = 0`, `x in [-1,1]`, `t in [0,1]`,
with `u(x,0)=-sin(pi x)` and `u(-1,t)=u(1,t)=0`.

## Included generated references

`run_all.py` independently generates high-resolution finite-volume reference files for three viscosity values and saves both `.npz` and `.mat` versions here. These make the project runnable even before the public file is downloaded. The public file is used as an external validation check for the canonical `nu=0.01/pi` case when present.
